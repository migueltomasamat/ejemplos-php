<?php
    include_once("./funcionesPlantilla.php");


    cabeceraHTML("Area Privada");