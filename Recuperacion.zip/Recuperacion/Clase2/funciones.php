<?php
    function mostrarMensajeChorra ($mensaje){

        echo $mensaje;
    }

